<p>
    Rp. {{ number_format($total, 0, '', '.') }}
</p>
