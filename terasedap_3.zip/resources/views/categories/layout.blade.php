<!DOCTYPE html>
<html>
<head>
    <title>Category Management</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
<div class="container" style="margin-top: 15px;">
    @yield('content')
</div>
   
</body>
</html>