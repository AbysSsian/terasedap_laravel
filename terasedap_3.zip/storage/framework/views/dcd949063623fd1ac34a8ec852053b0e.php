<div class="delete-menu-modal"
x-data="{show : false, menuId: '<?php echo e($menu->id); ?>'}"
x-show="show"
x-on:open-delete-menu-modal.window = "show = ($event.detail.menuId === menuId)"
x-on:close-delete-menu-modal.window= "show = false"
x-on:keydown.escape.window = "show=false"
style="display: none;"
wire:transition
>
    <div class="modal-background" x-on:click="$dispatch('close-delete-menu-modal')">
    </div>
    <div class="modal">
        <div class="modal-header">
            <div>
                Delete Menu
            </div>
            <div><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maki-cross'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'height:20px;','x-on:click' => '$dispatch(\'close-delete-menu-modal\')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="modal-body">
            <p>The menu <span style="font-weight: 600"><?php echo e($menu->name); ?></span> will be permanently deleted. Are you sure you want to continue?</p>
        </div>
        <div class="modal-footer">
            <button class="delete" wire:click="deleteMenu(<?php echo e($menu->id); ?>)">Delete</button>
            <button class="cancel" x-on:click="$dispatch('close-delete-menu-modal')">Cancel</button>
        </div>
    </div>
</div>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/delete-menu-modal.blade.php ENDPATH**/ ?>