<div id="list">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-item" wire:key="<?php echo e($category->id); ?>">
            <div class="list-item-info">
                <!--[if BLOCK]><![endif]--><?php if($category->id == $editCategoryId): ?>
                <input type="text" class="list-item-input" placeholder="Category..." wire:model="editCategoryName">
                <?php else: ?>
                <h3>
                    <?php echo e($category['name']); ?>

                </h3>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($category->id !== $editCategoryId): ?>
                <div>
                    <button wire:click.prevent="delete(<?php echo e($category->id); ?>)" wire:loading.remove class="delete-button"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-bro-trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width:18px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                    <span class="loader" wire:loading wire:target="delete(<?php echo e($category->id); ?>)"></span>
                    <button wire:click="edit(<?php echo e($category->id); ?>)" class="edit-button"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-lin-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width:18px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                </div>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <!--[if BLOCK]><![endif]--><?php if($category->id == $editCategoryId): ?>
            <div style="margin-top: 12px;">
                <button class="edit-button" style="font-size:17px;" wire:click="update" wire:loading.attr="disabled">Save</button>
                <button class="delete-button" style="font-size:17px;" wire:click="cancelEdit" wire:loading.attr="disabled">Cancel</button>
            </div>
                
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/category-list.blade.php ENDPATH**/ ?>