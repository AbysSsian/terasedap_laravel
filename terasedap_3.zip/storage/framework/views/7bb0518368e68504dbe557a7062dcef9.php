<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/livewire.css')); ?>">
<?php $__env->stopPush(); ?>
<div>
    <button class="cancel-edit-button" wire:click="cancelEdit"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-out-arrow-left-2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'height: 30px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
        Return
    </button>
    <main id="edit-order"> 
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Components.MenuList', ['ordercode' => ''.e($order->order_code).'']);

$__html = app('livewire')->mount($__name, $__params, 'h7UGBuW', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <div id="order-list">
            <h2>Order</h2>
            <div id="order-detail">
                <table>
                    <tr>
                        <td>Table Number</td>
                        <td>: <?php echo e($order->table_number); ?></td>
                    </tr>
                    <tr>
                        <td>Order Number</td>
                        <td>: <?php echo e($order->order_code); ?></td>
                    </tr>
                    <tr>
                        <td>Order Time</td>
                        <td>: <?php echo e($order->order_date); ?></td>
                    </tr>
                    <tr>
                        <td>Payment</td>
                        <td>: <?php echo e($order->payment_method); ?></td>
                    </tr>
                </table>
            </div>
            <div id="order-items">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->items()->onlyTrashed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="deleted-list-item">
                        <div>
                            <p>
                                <?php echo e($item->menu_name); ?>

                            </p>
                            <p>
                                Qty: <?php echo e($item->quantity); ?> <span>Canceled</span>
                            </p>
                            <div>
                                <?= nl2br($item->notes); ?>
                            </div>
                        </div>
                        <div>
                            <p>Rp. <?php echo e(number_format($item->total_price, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-list-item" x-data x-on:click="$dispatch('open-delete-item-modal', {itemId:'<?php echo e($item->id); ?>'})" wire:key="<?php echo e($item->id); ?>">
                        <div>
                            <p><?php echo e($item->menu_name); ?></p>
                            <p>Qty: <?php echo e($item->quantity); ?></p>
                            <div>
                                <?= nl2br($item->notes); ?>
                            </div>
                            <div>
                                <button class="delete-item" wire:click="deleteItem(<?php echo e($item->id); ?>)">Delete</button>

                            </div>
                        </div>
                        <div>
                            <div style="display: flex; justify-content: flex-end;">
                                <p>Rp. <?php echo e(number_format($item->total_price, 0, ',', '.')); ?></p>
                                <div>
                                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-out-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 20px; margin-left:10px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <div>
                                <div class="order-item-quantity">
                                    <button wire:click="decrementQuantity(<?php echo e($item->id); ?>)" <?php if($item->quantity == 1): ?>
                                    disabled
                                <?php endif; ?>><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-lin-minus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 18px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                                    <input type="number" min="1" disabled value="<?php echo e($item->quantity); ?>">
                                    <button wire:click="incrementQuantity(<?php echo e($item->id); ?>)"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-lin-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 18px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div id="order-foot">
                <div>
                    <button class="delete-button" wire:click="cancelOrder(<?php echo e($order->id); ?>)">
                        Cancel Order
                    </button>
                </div>
                <div id="save-changes">
                    <h2>Rp. <?php echo e(number_format($order->total_price, 0, '', '.')); ?></h2>
                    <button wire:click="cancelEdit">Save Changes</button>
                </div>
            </div>
        </div>
    </main>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/edit-order.blade.php ENDPATH**/ ?>