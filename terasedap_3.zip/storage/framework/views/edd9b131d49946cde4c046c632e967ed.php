<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/input.css')); ?>" />
    <title>Terasedap | Edit Menu</title>
</head>

<body>
    <div class="navbar">
        <div>
            <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
        </div>
        <ul>
            <li><a href="<?php echo e(route('admin.orders')); ?>">Orders</a></li>
            <li><a href="<?php echo e(route('admin.history')); ?>">Order History</a></li>
            <li><a href="<?php echo e(route('admin.menu')); ?>">Menu Management</a></li>
            <li><a href="<?php echo e(route('admin.category')); ?>">Category Management</a></li>
            <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
        </ul>
    </div>
    <main>
        <div style="display: flex; align-items:center">    
            <a href="<?php echo e(route('admin.menu')); ?>" style="margin-right: 10px"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-out-arrow-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 28px; color:#e9e9e9; font-weight:bold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>

            </a>
            <h2>Edit Menu</h2>
        </div>
        <div style="margin-top:32px; display:flex; justify-content: center;">
            <form action="<?php echo e(route('save_menu', $menu->id)); ?>" enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div id="editing">
                    <div id="image-upload">
                        
                        <div id="input-image">
                            <img src="<?php echo e($menu->getImageURL()); ?>" alt="menu-image">
                            <span>Select an image</span>
                            <input type="file" class="file" accept="image/*" id="image" name="image">
                        </div>
                    </div>
                    <div id="input-section">
                        <div class="input-row">
                            <div class="input-group">
                                <label for="name" class="input-label">Menu Name</label>
                                <input type="text" name="name" id="name" class="input-field" value="<?php echo e($menu->name); ?>">
                            </div>
                            <div class="input-group">
                                <label for="price" class="input-label">Price</label>
                                <input type="number" name="price" id="price" class="input-field" value="<?php echo e($menu->price); ?>">
                            </div>
                        </div>
                        <div class="input-row">
                            <div class="input-group">
                                <label for="description" class="input-label">Description</label>
                                <textarea class="input-area" name="description" id="description"><?php echo($menu->description) ?></textarea>
                            </div>
                            <div class="input-group">
                                <label for="category" class="input-label">Category</label>
                                <select name="category" id="category" class="input-field" style="height: 36px; width:310px">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($category->id == $menu->category_id): ?>
                                    <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endif; ?>    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="save-button">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
        
    </main>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <script>
        const input = document.querySelector('#input-image input');
        const preview = document.querySelector('#input-image img');

        input.addEventListener("change", () => {
            let file = input.files[0];

            preview.src = URL.createObjectURL(file);
        });
    </script>
    
</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/edit_food_item.blade.php ENDPATH**/ ?>