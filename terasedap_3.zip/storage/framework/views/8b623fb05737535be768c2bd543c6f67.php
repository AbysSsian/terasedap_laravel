<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 12h12"/>
</svg><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\storage\framework\views/b95b41827507c3e984c8b325ac21e921.blade.php ENDPATH**/ ?>