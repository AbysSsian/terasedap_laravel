<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 12h12M12 18V6"/>
</svg><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\storage\framework\views/aa08beca9995c4a1d159e2ea4a969f43.blade.php ENDPATH**/ ?>