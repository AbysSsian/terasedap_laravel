<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
</head>

<body>
    <nav>
        <center>
            <div class="logo">
                <a href="<?php echo e(route('food-items')); ?>">
                    <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
                </a>
            </div>
        </center>
        <div class="cart-icon">
            <a href="<?php echo e(route('cart.view')); ?>">
                <img src="<?php echo e(asset('images/cart.png')); ?>" alt="cart" />
            </a>
        </div>
    </nav>


    <div class="motto">Experience Indonesian Culinary</div>
    <div class="centered-list">
        <ul class="horizontal-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li onclick="scrollToSection('<?php echo e($category->name); ?>')"><?php echo e($category->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
	<div class="scroll-target" id="<?php echo e($category->name); ?>">
        <center>
            <h1 class="list"><?php echo e($category->name); ?></h1>
        </center>

        <div class="menu-list">
        <?php $__currentLoopData = $foodItems->where('category_id', $category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="menu-item">
                <a href="<?php echo e(route('fooditem.description', ['id' => $item->id])); ?>">
                    <?php if($item->image): ?>
                    <img src="<?php echo e(asset('images/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>">
                    <?php else: ?>
                    <p>No image available</p>
                    <?php endif; ?>
                </a>
                <div class="food-name"><?php echo e($item->name); ?></div>
                <div class="food-price">Rp.<?php echo e($item->price); ?></div>
                <div class="quantity-buttons">
                    <form
                        action="<?php echo e(route('cart.add', ['name' => $item->name, 'id' => $item->id, 'price' => $item->price])); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit">-</button>
                    </form>
                    <form
                        action="<?php echo e(route('cart.add', ['name' => $item->name, 'id' => $item->id, 'price' => $item->price])); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit">+</button>
                    </form>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
	</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
    function scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);

        if (section) {
            section.scrollIntoView({
                behavior: "smooth"
            });
        }
    }
    </script>

</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/display_food_items.blade.php ENDPATH**/ ?>