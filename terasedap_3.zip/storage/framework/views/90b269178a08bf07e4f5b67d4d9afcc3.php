<div 
x-data="{ show: false, orderId: '<?php echo e($orderId); ?>' }"
x-show="show"
x-on:open-delete-modal.window="show = ($event.detail.orderId === orderId)"
x-on:close-delete-modal.window="show = false"
style="z-index: -50; display:none;"
x-transition
>
    <div class="order-modal-background" x-on:click="show = false"></div>
    <form action=""  wire:submit="deleteOrder(<?php echo e($orderId); ?>)">
        <div class="order-modal">
            <div class="modal-header">
                <div class="modal-title">
                    Cancel Order
                </div>
                <div>
                    <button style="background: none; border:none;" x-on:click="show = false">
                        <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maki-cross'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'height:20px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    </button>
                </div>
            </div>
            <div class="modal-body">
                <h4>Why do you want to cancel this order?</h4>
                <textarea class="delete-modal-textarea" name="cancel_reason" id="cancel_reason" wire:model="cancel_reason" cols="30" rows="10"></textarea>
                <p>max char: 200</p>
            </div>
            <div class="modal-footer" style="width: 100%; display:flex;">
                <button class="modal-button cancel" type="submit">Cancel Order</button>
                <button class="modal-button close" x-on:click="show = false">Close</button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/delete-modal.blade.php ENDPATH**/ ?>