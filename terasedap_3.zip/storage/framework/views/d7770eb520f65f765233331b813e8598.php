<div>
    <input type="number" hidden value="<?php echo e($total); ?>" id="total_price" name="total_price">
</div>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/input-payment.blade.php ENDPATH**/ ?>