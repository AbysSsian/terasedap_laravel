<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/livewire.css')); ?>">
<?php $__env->stopPush(); ?>
<main>
    <style>
        #list {
            display: flex;
            flex-direction: column;
            justify-self: center;
        }
        .list-item {
            width: 88%;
            background: #4F4A45;
            padding: 0.75rem;
            margin-bottom: 4px;
        }
    </style>
    <div class="container admin">
        <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
            <div style="display:flex; margin-top: 12px; background-color: #fd3030; color:#ffa2a2; width:max-content; padding: 12px; border-radius: 12px;">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <div style="display: flex; justify-content: space-between">
            <h2>
                Category
            </h2>
        </div>
        <div class="input-category" style="margin-top: 12px;">
            <form action="" wire:submit="addCategory">
                <div>

                    <input wire:model="newCategory" class="input-field" type="text" name="newCategory" placeholder="New Category" autocomplete="off">
                </div>
                <button type="submit" class="sign-button" wire:loading.attr="disabled">
                    Create
                </button>
                <span class="loader" wire:target="addCategory" wire:loading></span>

            </form>
        </div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.category-list', []);

$__html = app('livewire')->mount($__name, $__params, 'CG8a4ff', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</main>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/category.blade.php ENDPATH**/ ?>