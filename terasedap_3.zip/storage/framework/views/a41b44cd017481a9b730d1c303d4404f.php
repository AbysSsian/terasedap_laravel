<div class="menu-list">
    <div class="image-name">
        <img src="<?php echo e($detail->getImageURL()); ?>" alt="<?php echo e($detail->name); ?>">
        <p><?php echo e($detail->name); ?></p>
    </div>
    <div class="price-button">
        <p>Rp. <?php echo e(number_format($detail->price, 0, ',', '.')); ?></p>
        <a href="<?php echo e(route('food-item.edit', $detail->id)); ?>" class="menu-edit-button">Edit</a>
        <button class="delete-button" x-data x-on:click="$dispatch('open-delete-menu-modal', {menuId: '<?php echo e($detail->id); ?>' })">Delete</button>
    </div>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/admin-menu.blade.php ENDPATH**/ ?>