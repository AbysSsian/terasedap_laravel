<?php echo e($url); ?> <br>
<?php echo e($code); ?><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/test.blade.php ENDPATH**/ ?>