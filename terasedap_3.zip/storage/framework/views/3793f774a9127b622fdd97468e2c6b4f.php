<div id="menu-list">
    <!--[if BLOCK]><![endif]--><?php if(isset($selectedCategory)): ?>
        
    <div class="menu-list-item" wire:click="resetCategory">
        <p>
            Back to Category
        </p>
    </div>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedCategory->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="menu-list-item" wire:click="addMenu(<?php echo e($menu->id); ?>)" wire:key="<?php echo e($menu->id); ?>">
            <p>
                <?php echo e($menu->name); ?>

            </p>
            
            <p>
                Rp. <?php echo e(number_format($menu->price, 0, ',', '.')); ?>

            </p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->



    <?php elseif(empty($selectedCategory)): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="menu-list-item" wire:click="selectCategory(<?php echo e($category->id); ?>)" wire:key="<?php echo e($category->id); ?>">
                <p>
                    <?php echo e($category->name); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->


</div>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/menu-list.blade.php ENDPATH**/ ?>