<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
    <title>Terasedap - Cart</title>
</head>
<body>
    <center>
        <div class="logo">
            <a href="<?php echo e(route('food-items')); ?>">
                <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
            </a>
        </div>
    </center>
    <div class="summary">
        <h2>Cart Summary</h2>
        <div id="cart-list">
            <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Components.CardItems', ['detail' => $item,'fooddetail' => $item->food]);

$__html = app('livewire')->mount($__name, $__params, ''.e($item->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="addmore">
            <a href="<?php echo e(route('food-items')); ?>">
                <img src="images/addmorebutton.png" alt="" />
            </a>
        </div>
        <div class="subtotal">
            <p>Total Payment</p>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Components.Subtotal', ['cart' => $cart]);

$__html = app('livewire')->mount($__name, $__params, 'hH79m8j', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <form action="<?php echo e(route('confirmOrder')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div style="width: 100%;">
                <div class="selection">
                    <h3>Select payment method</h3>
                    <select name="paymentMethod" id="paymentMethod">
                        <option value="cash">Cash</option>
                        <option value="qris">QRIS</option>
                        <option value="card">Card</option>
                    </select>
                </div>
                <div style="display: flex; width:100%; justify-content:flex-end;margin-top: 20px;">
                    <button type="submit" class="cart-order">Place Order</button>
                </div>
            </div>
        </form>
    </div>

    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Components.NotesModal', ['itemId' => ''.e($item->id).'']);

$__html = app('livewire')->mount($__name, $__params, ''.e($item->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/cart.blade.php ENDPATH**/ ?>