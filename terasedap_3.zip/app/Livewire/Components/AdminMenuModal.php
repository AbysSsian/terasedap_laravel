<?php

namespace App\Livewire\Components;

use Livewire\Component;

class AdminMenuModal extends Component
{
    public function render()
    {
        return view('livewire.components.admin-menu-modal');
    }
}
